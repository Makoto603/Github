# FlowSpec Refiner

ChatGPT / Codex向けのFlowSpecレビューSkillです。

## ChatGPT Web
アップロード画面では、まず `SKILL.md` 単体を試してください。
ZIPを使う場合は `flowspec-refiner.zip`、`.skill` が受理される環境では `flowspec-refiner.skill` を利用できます。

## Primary input
- `.flowspec.zip`
- `flow.json`

## Output
- consolidated review
- `review.json`
- `suggested_changes`
