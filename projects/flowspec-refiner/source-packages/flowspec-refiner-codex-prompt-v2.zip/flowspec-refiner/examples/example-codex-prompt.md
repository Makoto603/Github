# Codex Development Request

## Project

- プロジェクト名: Sample App

## Purpose

FlowSpecで定義された入力を検証し、条件に応じて処理結果またはエラーを返すアプリを実装する。

## Source of Truth

仕様は次の優先順位で参照する。

1. `flow.json`
2. `refined_requirements.md`
3. `project.md`
4. `review.json`
5. その他参考資料

`review.json` の未解決Issueは正式仕様ではない。指摘または改善候補として扱う。

## Development Rules

- `flow.json` を仕様の一次情報として扱う。
- FlowSpecに存在しない機能を勝手に追加しない。
- 曖昧な仕様を独自判断で確定しない。
- 一問ずつユーザーへ質問せず、問題をまとめて報告する。
- FlowSpecノードIDを可能な限り実装・コメント・テスト・ログへ紐付ける。
- 既存仕様の変更が必要な場合は実装前に報告する。
- 未解決Issueが重大な場合は該当部分の実装を保留する。
- 外部仕様を変えない内部実装方式はCodexの裁量とする。
- リファクタリングで仕様上の挙動を変更しない。
- エラーを握り潰さない。
- TODOで仕様不足を隠さない。

## Known Issues

### ISSUE-002

- severity: warning
- node_id: N004
- title: 判定基準が曖昧です
- description: 「正常か」の客観的な判定条件が定義されていません。
- implementation_risk: true
- requires_human_decision: true

このIssueの提案は承認済み仕様ではない。N004に依存する確定実装は保留し、他の安全な範囲を進める。

## Implementation Scope

- 主な画面: 未定義
- 主な処理: 入力受付、入力検証、条件分岐、結果返却
- 外部システム: 未定義
- 入力: FlowSpecで定義された入力データ
- 出力: 処理結果またはエラー
- データ保存: 未定義
- エラー処理: 入力不正時の失敗経路。詳細は未定義
- サブフロー: 未定義
- 外部依存: 未定義

## First Actions

1. リポジトリ構成を確認する。
2. `AGENTS.md` があれば最優先で読む。
3. FlowSpec一式を読む。
4. 実装対象と未解決Issueを整理する。
5. 既存コードがある場合はFlowSpecとの乖離を確認する。
6. 実装計画を作成する。
7. 重大な仕様不足がない範囲から実装を開始する。

## Output Expectations

- 実装計画
- 変更ファイル一覧
- 実装内容
- テスト結果
- 未解決Issue
- FlowSpecとの乖離
- 必要に応じた `review.json` 更新案
