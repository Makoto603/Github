# CODEX_PROMPT.md Generation Rules

## Role boundary

Generate a development-start prompt from a reviewed FlowSpec. Do not implement the application, silently resolve product decisions, or turn suggestions into authoritative requirements.

## When to generate

Generate `CODEX_PROMPT.md` after review unless the user explicitly requests review or findings only. Always generate it when the request asks to prepare, polish, or summarize a FlowSpec for Codex or development.

## Required structure

Use these headings in this order:

1. `# Codex Development Request`
2. `## Project`
3. `## Purpose`
4. `## Source of Truth`
5. `## Development Rules`
6. `## Known Issues`
7. `## Implementation Scope`
8. `## First Actions`
9. `## Output Expectations`

## Project

- Use the explicit project name when present.
- If absent, derive a concise provisional application name from `project.description` or the closest equivalent description.
- Mark a derived name as provisional and do not write it into `flow.json`.

## Purpose

Summarize the intended application from `project.description`, the complete reachable flow, and requirements. Do not add goals that are not supported by those sources.

## Source of Truth

State this default precedence:

1. `flow.json`
2. `refined_requirements.md`
3. `project.md`
4. `review.json`
5. Other reference material

Explain that unresolved content in `review.json` is a warning or proposal, not an authoritative specification. If an archive uses different filenames, preserve the same semantic precedence and name the actual files.

## Development Rules

Include all of the following:

- Treat `flow.json` as the primary specification.
- Do not add functionality absent from the FlowSpec.
- Do not decide ambiguous product behavior independently.
- Do not ask the user one question at a time; consolidate specification problems.
- Link FlowSpec node IDs to implementation, comments, tests, or logs where practical.
- Report any required change to existing behavior before implementing it.
- Defer affected implementation when an unresolved issue is critical.
- Allow Codex discretion over internal design only when external behavior remains unchanged.
- Do not alter specified behavior during refactoring.
- Do not swallow errors.
- Do not hide missing specifications behind TODOs.

## Known Issues

Include unresolved issues only. Treat an Issue as unresolved when:

- `resolution_status` is `unresolved` or `deferred`; or
- no resolution field exists and the review does not otherwise explicitly mark it resolved or accepted.

For every included Issue, provide:

- `issue id`
- `severity`
- `node_id` (`未定義` when absent)
- `title`
- `description`
- `implementation_risk` (`false` when absent unless the review clearly says otherwise)
- `requires_human_decision` (`false` when absent unless a linked suggested change or the Issue itself requires a human decision)

Do not promote an Issue's suggestion into a requirement. If there are no unresolved issues, say so explicitly.

## Implementation Scope

Extract and organize:

- Main screens
- Main processes
- External systems
- Inputs
- Outputs
- Data persistence
- Error handling
- Subflows
- External dependencies

Write `未定義` for unsupported or unknown items. Do not infer a framework, database, authentication method, file format, deployment target, or UI behavior unless specified.

## First Actions

Direct Codex to:

1. Inspect the repository structure.
2. Read `AGENTS.md` first when present.
3. Read the complete FlowSpec package.
4. Summarize implementation targets and unresolved issues.
5. Compare existing code against the FlowSpec when code exists.
6. Create an implementation plan.
7. Begin implementation when no critical specification gap blocks the relevant work.

## Output Expectations

Request:

- Implementation plan
- Changed-file list
- Implemented behavior
- Test results
- Unresolved issues
- Deviations from FlowSpec
- Proposed `review.json` updates when useful

## Quality checks

Before delivering the prompt, verify that:

- all required headings exist;
- referenced filenames actually exist or are clearly conditional;
- every unresolved Issue is represented once;
- resolved Issues are excluded;
- no suggested change is stated as approved unless the source records approval;
- every unknown scope item is marked `未定義`;
- the prompt tells Codex to stop only the affected work for critical unresolved issues, rather than blocking unrelated safe work;
- the prompt does not instruct this Skill to implement the application.
