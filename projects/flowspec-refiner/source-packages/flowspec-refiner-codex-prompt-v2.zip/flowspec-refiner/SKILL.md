---
name: flowspec-refiner
description: Review and refine FlowSpec Studio .flowspec.zip or flow.json files, and prepare reviewed specifications for Codex development. Use for FlowSpec review, specification cleanup, implementation-readiness checks, or generating a Codex-ready CODEX_PROMPT.md without silently changing the authoritative FlowSpec.
---

# FlowSpec Refiner

## Purpose
FlowSpec Studio から出力された `.flowspec.zip` または `flow.json` をレビューし、「AI/Codexが実装時に迷いにくい仕様」へブラッシュアップする。レビュー済み仕様から、Codexで新規開発を安全に開始するための `CODEX_PROMPT.md` も生成する。

このSkillはユーザーの仕様を勝手に確定変更しない。問題点と改善案をまとめて返し、人間が FlowSpec Studio で採用・編集・却下できる形式を優先する。

## When to use
以下のいずれかに該当するとき使用する。

- `.flowspec.zip` が添付された
- `flow.json` / FlowSpec JSON が添付された
- FlowSpecのレビュー、ブラッシュアップ、仕様の穴の確認を依頼された
- Codexへ渡す前に仕様の曖昧さ・漏れ・矛盾を確認したい
- 「Codexに渡せる形」「開発開始用」「開発用にブラッシュアップ」など、レビュー後の開発準備を依頼された
- レビュー済みFlowSpecからCodex初期プロンプトの生成を依頼された

通常の画像フローチャートだけが与えられた場合は正規入力ではない。可能なら構造化FlowSpecを優先する。

## Authoritative input
優先順位:
1. `flow.json` — 仕様の正本
2. `manifest.json` — FlowSpecバージョン、補助メタデータ
3. `project.md` — 目的・背景
4. `requirements.md` — 人間向け説明。`flow.json` と矛盾する場合は正本ではない

## Required workflow
1. 入力ファイルを確認する。
2. `.flowspec.zip` の場合は内容を展開して `flow.json` を特定する。
3. `flow.json` を解析する。
4. JSON/必須項目レベルの構造検査を行う。
5. グラフ構造検査を行う。
6. 実装仕様としての曖昧性を検査する。
7. データ受け渡し、外部依存、エラー処理、終了条件を検査する。
8. 指摘を重要度付きで一括してまとめる。
9. 可能な場合は `suggested_changes` を作る。
10. ユーザーの依頼内容に従って出力モードを決める。
11. レビューだけ・指摘だけと明示された場合を除き、レビュー完了後に `CODEX_PROMPT.md` を生成する。特に開発準備を含む依頼では必須とする。
12. ユーザーに一問ずつ質問しない。判断が必要な事項はまとめてレビューへ入れる。
13. ユーザーの明示的承認なしに正本FlowSpecを確定変更しない。

## Review categories
- `structure`: JSON/ノード/Edge構造
- `flow_logic`: 分岐、到達不能、重複、ループ、終了条件
- `ambiguity`: 判定条件や処理内容の曖昧さ
- `data_contract`: 入力、出力、ファイル形式、データ構造
- `error_handling`: 異常系、再試行、復旧
- `external_dependency`: API、MCP、CLI、外部ツール、モデル
- `requirement_gap`: 実装に必要だが仕様に存在しない事項
- `naming`: 表記揺れ、誤字、意味が曖昧な名称
- `implementation_risk`: 実装時にAIが推測しそうな危険箇所

## Severity
- `error`: フローとして破綻、矛盾、または実装不能になる可能性が高い
- `warning`: 実装時の手戻りや勝手な解釈につながりやすい
- `info`: 品質向上・表記整理・追加説明の提案

## Structural checks
最低限以下を確認する。

- startノードの有無
- endノードの有無
- ノードIDの重複
- Edge IDの重複
- 存在しないノードへのEdge
- 同一 `from` / `to` / `condition` の重複Edge
- 開始点から到達不能なノード
- 終了不能な経路
- decisionノードの分岐不足
- 同一decisionから同一条件が複数存在しないか
- ループに終了条件があるか
- subflow参照先の存在

## Specification-quality checks
各重要ノードについて必要に応じて確認する。

- 何を入力として受けるか
- 何を出力するか
- 成功条件は何か
- 失敗条件は何か
- decisionの判定基準は人間以外でも再現可能か
- 外部ツールの呼び出し条件と戻り値は何か
- ファイル形式・保存先・命名規則は必要か
- 再試行するか、失敗終了するか
- 人間判断が必要な箇所は明示されているか
- AIに任せてよい自由度と固定仕様が区別されているか

詳細ルールは `references/REVIEW_RULES.md` を参照する。

## Codex development preparation

`CODEX_PROMPT.md` は実装そのものではなく、Codexが実装を開始するための依頼文である。生成時は `references/CODEX_PROMPT_RULES.md` を読み、同ファイルの必須構成・仕様優先順位・未解決Issueの扱いに従う。形式例が必要な場合だけ `examples/example-codex-prompt.md` を参照する。

プロジェクト名が未設定なら `project.description` または同等の説明から仮名を生成してよいが、FlowSpec本体には書き戻さない。実装範囲で不明な項目は推測せず `未定義` とする。

## Review output
可能なら `review.json` を `schemas/review.schema.json` に従って作る。

最低限:
- `review_version`
- `source`
- `summary`
- `issues[]`
- `suggested_changes[]`

Issueは可能な限り `node_id` または `edge_id` を持たせる。

既存schemaとの後方互換性を保つ。Issueの判断要否や解決状態を記録できる場合は、任意項目 `requires_human_decision` と `resolution_status` を使う。既存の必須項目を削除・変更しない。

## Standard artifacts

可能な場合は次を生成する。

- `review.json` — 構造化レビュー
- `proposed_flow.json` — 正本を変更しない改善案。必要な場合のみ
- `refined_requirements.md` — 整理済み要件。必要な場合のみ
- `review_summary.md` — 人間向けレビュー要約
- `CODEX_PROMPT.md` — Codex開発開始用プロンプト

`proposed_flow.json` と `refined_requirements.md` は有用でなければ省略できる。`CODEX_PROMPT.md` はレビュー完了後に生成可能な設計にし、レビュー限定の明示がなければ生成する。

## Suggested changes policy
自動提案してよい例:
- 完全重複Edgeの削除
- 明らかな誤字の名称修正
- 到達不能で意図が明白な接続候補の提示

人間の仕様判断が必要な例:
- 「画像が適合している」の閾値
- エラー時に再試行するか終了するか
- データ保存期間
- 認証方式

後者は `suggested_changes` に含めてもよいが `requires_human_decision: true` にする。

## Final response
レビュー完了時は簡潔に以下を示す。

1. 総評
2. `error / warning / info` 件数
3. 重大な指摘の要約
4. FlowSpec Studioへ戻せる構造化レビュー成果物がある場合は案内
5. `CODEX_PROMPT.md` を生成した場合は、Codexへそのまま渡せることを案内

レビュー項目をチャットだけに散らさず、可能な限り構造化レビューとしてまとめる。

## Do not
- FlowSpecにないアプリ仕様を事実として追加しない
- 一問ずつ仕様確認を繰り返さない
- 画像だけを正本扱いしない
- 実装方法の好みと仕様不足を混同しない
- ユーザー承認前に提案を正式仕様と断定しない
- 未解決Issueを正式仕様として扱わない
- FlowSpec Refiner自身がアプリ実装を開始しない
- `flowspec-developer` 相当の実装責務を取り込まない
