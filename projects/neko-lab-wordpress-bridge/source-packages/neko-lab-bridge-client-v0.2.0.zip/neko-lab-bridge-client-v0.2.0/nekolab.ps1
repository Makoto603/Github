param(
    [Parameter(Mandatory=$true)]
    [ValidateSet('status','list','get','create','update','media','taxonomies')]
    [string]$Action,

    [int]$PostId,
    [string]$JsonFile,
    [string]$MediaFile,
    [string]$AltText = '',
    [string]$MediaTitle = '',
    [string]$Search = '',
    [int]$Page = 1,
    [int]$PerPage = 20
)

$ErrorActionPreference = 'Stop'

function Get-NlbConfig {
    $path = Join-Path (Join-Path $env:LOCALAPPDATA 'NekoLabBridge') 'config.json'
    if (-not (Test-Path $path)) {
        throw "Neko Lab Bridge is not configured. Run .\setup.ps1 first."
    }
    return (Get-Content -Raw -Encoding UTF8 $path | ConvertFrom-Json)
}

function Get-NlbHeaders($cfg) {
    if ($cfg.auth_mode -eq 'bridge_key' -and $cfg.api_key_dpapi) {
        $secure = ConvertTo-SecureString $cfg.api_key_dpapi
        $cred = New-Object System.Management.Automation.PSCredential('nlb', $secure)
        $plain = $cred.GetNetworkCredential().Password
        try {
            return @{
                'X-Neko-Lab-Key' = $plain
                Accept = 'application/json'
            }
        }
        finally { $plain = $null }
    }
    throw "Unsupported or missing auth configuration. Run .\setup.ps1 again."
}

function Invoke-NlbJson {
    param(
        [string]$Method,
        [string]$Uri,
        [hashtable]$Headers,
        [string]$Body
    )
    $params = @{
        Uri = $Uri
        Method = $Method
        Headers = $Headers
        ErrorAction = 'Stop'
    }
    if ($PSBoundParameters.ContainsKey('Body') -and $null -ne $Body) {
        $params['Body'] = $Body
        $params['ContentType'] = 'application/json; charset=utf-8'
    }
    return Invoke-RestMethod @params
}

$cfg = Get-NlbConfig
$base = $cfg.site_url.TrimEnd('/') + '/wp-json/neko-lab/v1'
$headers = Get-NlbHeaders $cfg

try {
    switch ($Action) {
        'status' {
            $result = Invoke-NlbJson -Method 'GET' -Uri "$base/status" -Headers $headers
        }
        'list' {
            $q = "page=$Page&per_page=$PerPage"
            if (-not [string]::IsNullOrWhiteSpace($Search)) {
                $q += '&search=' + [uri]::EscapeDataString($Search)
            }
            $result = Invoke-NlbJson -Method 'GET' -Uri "$base/drafts?$q" -Headers $headers
        }
        'get' {
            if ($PostId -le 0) { throw '-PostId is required for get.' }
            $result = Invoke-NlbJson -Method 'GET' -Uri "$base/drafts/$PostId" -Headers $headers
        }
        'create' {
            if ([string]::IsNullOrWhiteSpace($JsonFile)) { throw '-JsonFile is required for create.' }
            if (-not (Test-Path $JsonFile)) { throw "JSON file not found: $JsonFile" }
            $body = Get-Content -Raw -Encoding UTF8 $JsonFile
            $null = $body | ConvertFrom-Json
            $result = Invoke-NlbJson -Method 'POST' -Uri "$base/drafts" -Headers $headers -Body $body
        }
        'update' {
            if ($PostId -le 0) { throw '-PostId is required for update.' }
            if ([string]::IsNullOrWhiteSpace($JsonFile)) { throw '-JsonFile is required for update.' }
            if (-not (Test-Path $JsonFile)) { throw "JSON file not found: $JsonFile" }
            $body = Get-Content -Raw -Encoding UTF8 $JsonFile
            $null = $body | ConvertFrom-Json
            $result = Invoke-NlbJson -Method 'PUT' -Uri "$base/drafts/$PostId" -Headers $headers -Body $body
        }
        'media' {
            if ([string]::IsNullOrWhiteSpace($MediaFile)) { throw '-MediaFile is required for media.' }
            if (-not (Test-Path $MediaFile)) { throw "Media file not found: $MediaFile" }
            $bytes = [IO.File]::ReadAllBytes((Resolve-Path $MediaFile))
            if ($bytes.Length -gt 10MB) { throw 'Media file exceeds the 10 MiB plugin limit.' }
            $payload = [ordered]@{
                filename = [IO.Path]::GetFileName($MediaFile)
                data_base64 = [Convert]::ToBase64String($bytes)
                alt_text = $AltText
                title = $(if ([string]::IsNullOrWhiteSpace($MediaTitle)) { [IO.Path]::GetFileNameWithoutExtension($MediaFile) } else { $MediaTitle })
            }
            $body = $payload | ConvertTo-Json -Depth 6 -Compress
            $result = Invoke-NlbJson -Method 'POST' -Uri "$base/media" -Headers $headers -Body $body
        }
        'taxonomies' {
            $result = Invoke-NlbJson -Method 'GET' -Uri "$base/taxonomies" -Headers $headers
        }
    }

    $result | ConvertTo-Json -Depth 12
}
catch {
    $message = $_.Exception.Message
    $statusCode = $null
    $responseBody = $null
    if ($_.Exception.Response) {
        try { $statusCode = [int]$_.Exception.Response.StatusCode } catch {}
        try {
            $stream = $_.Exception.Response.GetResponseStream()
            if ($stream) {
                $reader = New-Object IO.StreamReader($stream)
                $responseBody = $reader.ReadToEnd()
            }
        } catch {}
    }
    [ordered]@{
        ok = $false
        action = $Action
        status_code = $statusCode
        error = $message
        response = $responseBody
    } | ConvertTo-Json -Depth 8
    exit 1
}
