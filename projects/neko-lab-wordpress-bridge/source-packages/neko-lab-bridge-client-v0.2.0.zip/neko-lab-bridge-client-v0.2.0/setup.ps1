param(
    [string]$SiteUrl = "https://neconini.com"
)
$ErrorActionPreference = 'Stop'
$SiteUrl = $SiteUrl.TrimEnd('/')
$SecureKey = Read-Host "Neko Lab Bridge API Key" -AsSecureString
$EncryptedKey = ConvertFrom-SecureString $SecureKey
$ConfigDir = Join-Path $env:LOCALAPPDATA 'NekoLabBridge'
$ConfigPath = Join-Path $ConfigDir 'config.json'
New-Item -ItemType Directory -Path $ConfigDir -Force | Out-Null
$Config = [ordered]@{
    site_url = $SiteUrl
    auth_mode = 'bridge_key'
    api_key_dpapi = $EncryptedKey
    created_at = (Get-Date).ToString('o')
}
$Config | ConvertTo-Json -Depth 4 | Set-Content -Path $ConfigPath -Encoding UTF8
Write-Host "Saved encrypted Neko Lab Bridge API key to: $ConfigPath"
Write-Host "The API key is encrypted for the current Windows user and is not stored in plaintext."
