# Neko Lab Bridge Client v0.2.0

WindowsからNeko Lab Bridge v0.2+を操作するPowerShellクライアントです。

## 初期設定

1. WordPress管理画面の **ツール → Neko Lab Bridge** を開く。
2. `neko-lab-editor` を選び、**APIキーを生成 / 再生成**。
3. 表示されたAPIキーをコピー。キーはWordPress側ではハッシュ保存され、この画面では再表示されません。
4. PowerShellで以下を実行。

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\setup.ps1 -SiteUrl "https://neconini.com"
```

表示された `Neko Lab Bridge API Key:` にキーを貼り付けます。入力内容は画面には表示されません。Windows側ではDPAPI暗号化して保存します。

## 接続確認

```powershell
.\nekolab.ps1 -Action status
```

`ok: true` なら接続完了です。

## 下書き作成

```powershell
.\nekolab.ps1 -Action create -JsonFile .\examples\article.json
```

公開・削除操作はプラグイン側に存在しません。
